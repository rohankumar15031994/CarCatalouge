import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface ICars {
  name: string;
  brand: string;
  price: number;
 mileage : number;
  
}
export interface IDistinctCars {
  count: number;
  brand: string; 
}
@Injectable()
export class CarService {
  
    constructor(
        private http: HttpClient
      ) {}
      hasValue(object) {
        return (object !== undefined && object !== "" && object !== null)
      }
      car_data: ICars[] = [ {"name": "Breeza","brand": "Maruti","price": 10,"mileage" : 18 },
    {"name": "Nexon","brand": "Tata","price": 9,"mileage" : 16 },
    {  "name": "Creta", "brand": "Hyundai", "price": 15,"mileage" : 12 },
    { "name": "i10",  "brand": "Hyundai",   "price": 8,"mileage" : 16 },
    {  "name": "Alto",  "brand": "Maruti", "price": 4,"mileage" : 18 },
    {"name": "City",  "brand": "Honda",  "price": 11,"mileage" : 13 }
    ]

}