import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {CarComponent} from 'src/app/carcatalouge/carcatalouge.component';
import { HttpClient ,HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import {CarService} from 'src/services/carcatalougeservice';
import { MatButtonModule, MatFormFieldModule,MatInputModule} from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng2SearchPipeModule } from 'ng2-search-filter'; 


@NgModule({
  declarations: [
    AppComponent,
    CarComponent
  ],
  entryComponents: [CarComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    MatFormFieldModule,
    MatButtonModule,
    MatDialogModule,
    BrowserAnimationsModule,
    MatInputModule,
    Ng2SearchPipeModule
  ],
  providers: [CarService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
