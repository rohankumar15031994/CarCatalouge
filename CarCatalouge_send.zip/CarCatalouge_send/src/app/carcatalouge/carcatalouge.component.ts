import { Component, OnInit } from '@angular/core';
import { CarService,IDistinctCars } from 'src/services/carcatalougeservice';


@Component({
  selector: 'app-carcatalougecomponent',
  templateUrl: './carcatalouge.component.html',
  styleUrls: ['./carcatalouge.component.css']
})

export class CarComponent implements OnInit {
  searchText;
  distinctCarList : IDistinctCars[] =[];
  distinctcars = [];
  showdDistinctBrands = true;
  count = [];
  distinctEmployeesWithCount = [];
  constructor(private carservice: CarService) { 
     
    }
    carList = this.carservice.car_data;
    sortData(){
    this.carList.sort((a,b) => a.name.localeCompare(b.name));
    }
    getDistinctBrands(){
      this.distinctCarList = [];
      for(var i=0; i < this.carList.length; i++){
        if(this.distinctcars.indexOf(this.carList[i].brand) === -1){
          this.distinctcars.push(this.carList[i].brand);
        }
       
        
      }
      for(var i=0; i < this.distinctcars.length; i++){
      this.count.push(this.carList.filter(x => x.brand === this.distinctcars[i]).length);
      }
      for(var i=0; i< this.distinctcars.length; i++)  {
        this.distinctCarList.push({brand: this.distinctcars[i], count: this.count[i]});
    }
      this.showdDistinctBrands = false;
      
    }
   
  ngOnInit() {
 
    
  }

}
