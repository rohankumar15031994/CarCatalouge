import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductaddeditdialogComponent } from './productaddeditdialog.component';

describe('ProductaddeditdialogComponent', () => {
  let component: ProductaddeditdialogComponent;
  let fixture: ComponentFixture<ProductaddeditdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductaddeditdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductaddeditdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
